# Stardew Valley 星露谷物語全方位 RAG 教學資料集

整理日期：2026-11-02  |  共 24 篇 UTF-8 TXT，每篇對應一個官方中文 Wiki 條目。

本資料集為教學用原創改寫摘要，不是 Wiki 網頁全文，且不包含圖片。原始資料來自社群共同維護的 Stardew Valley 官方中文 Wiki（https://zh.stardewvalleywiki.com/）。
Wiki 文字授權：CC BY-NC-SA 3.0（署名、非商業性使用、相同方式分享），授權參考：https://zh.stardewvalleywiki.com/Stardew_Valley_Wiki:关于 。遊戲圖片、美術與遊戲本身的權利另歸原權利人。若再分享改寫資料，請維持署名及相同方式分享的授權條件。

## 對應教師的 RAG01

1. 直接把 rag-data.zip 上傳到 RAG01 的原始教材 ZIP 上傳步驟。
2. 所有 .txt 都使用「標題：」「來源網址：」「教材整理日期：」「【內容】」這些欄位，可直接搭配原範例 extract_rag_text() 和 extract_metadata()。
3. EXPECTED_DOCUMENT_COUNT 應設為 24 或 None。
4. 執行 RAG01 後才會建立 FAISS 索引，並匯出供 RAG02 使用的「vector_embedding.zip」（或你在程式中自訂的向量索引 ZIP 名稱）。
5. 原始 rag-data.zip **不是** 向量資料庫 ZIP，不能直接拿去 RAG02。
6. RAG02 的 SYSTEM_PROMPT 應換成星露谷遊戲助教，並更新示例問題。

## 注意
- 原始來源是簡體中文 Wiki 網頁；TXT 的檔名、標題、摘要與附帶說明均採繁體中文，來源網址保留原始路徑；百科內容可能包含版本差異或條目待校訂之處。
- 這是涵蓋主要系統的入門知識摘要，不是逐個魚種、村民禮物或農作物價格的完整資料表。涉及精確數值而資料未收錄的問題，應回答「這份資料沒有足夠資訊」。
- sources.csv 列出全部 24 個來源文章原始網址與繁體中文檔名。

## 來源文章
01. 新手指南：https://zh.stardewvalleywiki.com/新手指南
02. 遊戲內時間：https://zh.stardewvalleywiki.com/游戏内时间
03. 技能與職業：https://zh.stardewvalleywiki.com/技能
04. 四季與換季：https://zh.stardewvalleywiki.com/季节
05. 農作物與種植：https://zh.stardewvalleywiki.com/农作物
06. 動物與畜牧：https://zh.stardewvalleywiki.com/动物
07. 雞舍與升級：https://zh.stardewvalleywiki.com/鸡舍
08. 農舍與房屋升級：https://zh.stardewvalleywiki.com/农舍
09. 溫室與全年種植：https://zh.stardewvalleywiki.com/温室
10. 工匠物品與加工：https://zh.stardewvalleywiki.com/工匠物品
11. 工具與升級：https://zh.stardewvalleywiki.com/工具
12. 釣魚操作與技巧：https://zh.stardewvalleywiki.com/钓鱼
13. 魚類與出現條件：https://zh.stardewvalleywiki.com/鱼
14. 礦井與採礦：https://zh.stardewvalleywiki.com/矿井
15. 武器與戰鬥：https://zh.stardewvalleywiki.com/武器
16. 野外採集：https://zh.stardewvalleywiki.com/采集
17. 村民與人物：https://zh.stardewvalleywiki.com/居民
18. 友誼與送禮：https://zh.stardewvalleywiki.com/友谊
19. 任務系統：https://zh.stardewvalleywiki.com/任务
20. 社區中心收集包：https://zh.stardewvalleywiki.com/收集包
21. 社區中心與修復：https://zh.stardewvalleywiki.com/社区中心
22. 烹飪與食譜：https://zh.stardewvalleywiki.com/烹饪
23. 節日與活動：https://zh.stardewvalleywiki.com/节日
24. 薑島與後期探索：https://zh.stardewvalleywiki.com/姜岛

提醒：老師的 RAG01 範例在讀取 metadata 時，若某欄位未提供，仍會自動填入「未標示」。如果不想在向量資料庫的 metadata 內保留那個欄位，可在 RAG01 的 extract_metadata() 回傳字典中刪除該欄位對應的鍵值。
